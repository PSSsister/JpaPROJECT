package dao;

import java.util.HashMap;

import bean.TransactionBean;
import bean.User;

public interface PaymentWalletDao {
	
	void userAccountCreate(User userbean);
	String showBalance(Integer accountId,String password);
	String Deposit(Integer accountNo, String password, Integer amount);
	String withDraw(Integer accountNo, String password, Integer amount);
	String fundTransfer(Integer accountNo, String password, Integer destAccountNo,Integer amount);
	HashMap<Integer, TransactionBean> printTransactions(Integer accountNo);
	boolean validAccountId(Integer accountNo);
    boolean checkBalance(Integer accountNo, Integer amount);
}
