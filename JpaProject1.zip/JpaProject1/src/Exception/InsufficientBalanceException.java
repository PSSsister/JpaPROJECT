package Exception;
@SuppressWarnings("serial")
public class InsufficientBalanceException extends RuntimeException{
	public InsufficientBalanceException(String message) {
		
		super(message);
		System.out.println("this is error");
		}
}
