package Exception;
@SuppressWarnings("serial")
public class AccountNotExist  extends RuntimeException{
	
	public AccountNotExist(String message) {
		
		super(message);
		System.out.println("this is error");
		}
}
