package bean;

import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="transaction2")
public class TransactionBean {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	 private Integer transactionId;
	   private String transactionType;
	   private Integer toAccountId;
	   private Timestamp transactiondate;
	   private int amount;
	   private Integer accountNo;
	public Integer getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(Integer transactionId) {
		this.transactionId = transactionId;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public Integer getToAccountId() {
		return toAccountId;
	}
	public void setToAccountId(Integer toAccountId) {
		this.toAccountId = toAccountId;
	}
	public Timestamp getTransactiondate() {
		return transactiondate;
	}
	public void setTransactiondate(Timestamp transactiondate) {
		this.transactiondate = transactiondate;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public Integer getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(Integer accountNo) {
		this.accountNo = accountNo;
	}


}
